-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2021 at 06:01 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`) VALUES
(5, 'admin', 'admin'),
(6, 'abc', 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `categoryName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `platform`
--

CREATE TABLE `platform` (
  `plt_id` int(11) NOT NULL,
  `plt_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `platform`
--

INSERT INTO `platform` (`plt_id`, `plt_name`) VALUES
(4, 'MT5'),
(16, ''),
(17, '');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `sl` int(11) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `userguide` varchar(100) DEFAULT NULL,
  `description` text NOT NULL,
  `input_description` text DEFAULT NULL,
  `validity` varchar(50) DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `Platform` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`sl`, `category`, `name`, `cost`, `discount`, `image`, `userguide`, `description`, `input_description`, `validity`, `tags`, `Platform`) VALUES
(4, 'Expert Advisor', 'TEST', 4444, 333, 'screenshot-localhost-2021.08.06-10_52_47.png', 'screenshot-localhost-2021.08.06-12_14_02.png', 'df', 'ghfd', 'One month', 'fdd', 'MT4'),
(5, 'Indicator', 'ca', 12, 100, 'screenshot-localhost-2021.08.06-12_14_02.png', 'screenshot-localhost-2021.08.06-12_14_02.png', 'a', 'a', 'One year', 'a', 'MT4'),
(6, 'MT4', 'a', 1, 12, 'input of project.PNG', 'input of project.PNG', 'nn', 'a', 'One month', 'a', ''),
(12, 'MT4', 'a', 0, 0, 'screenshot-localhost-2021.08.09-18_14_30.png', 'screenshot-localhost-2021.08.06-10_52_47.png', 'a', 'a', 'One month', 'a', ''),
(13, 'MT4', 'a', 0, 0, 'screenshot-localhost-2021.08.05-11_59_20.png', 'screenshot-localhost-2021.08.06-10_52_47.png', 'a', 'a', 'One month', 'a', ''),
(14, 'MT4', 'adsinvk', 0, 0, 'screenshot-localhost-2021.08.05-11_59_20.png', 'screenshot-localhost-2021.08.06-10_52_47.png', 'a', 'a', 'One month', 'a', ''),
(15, 'MT4', 'afvb', 11111100000, 1.11111e15, '', 'screenshot-localhost-2021.08.05-11_59_39.png', 'dvc jgj', 'asdfghj', 'One month', 'aaaaaaaaaaaaaaa', ''),
(16, 'MT4', 'aaaaaaaaaaaaaaaa', 10, 10, '', 'screenshot-localhost-2021.08.05-11_59_20.png', 'a', 'a', 'One month', 'a', ''),
(17, 'MT4', 'a', 10, 10, 'screenshot-localhost-2021.08.05-11_59_39.png', 'screenshot-localhost-2021.08.09-18_14_30.png', 'a', 'a', 'One month', 'a', ''),
(18, 'MT4', 'a', 10, 10, 'screenshot-localhost-2021.08.06-10_52_47.png', 'screenshot-localhost-2021.08.06-10_52_47.png', 'a', 'a', 'One month', 'a', ''),
(19, 'MT4', 'a', 10, 10, 'IMG_20200813_215923 (6).jpg', 'screenshot-localhost-2021.08.06-10_52_47.png', 'a', 'a', 'One month', 'a', ''),
(33, 'MT4', 'a', 0, 0, '', 'screenshot-localhost-2021.08.06-10_52_47.png', 'aaa', 'aaaaaaaaa', 'One month', 'aaaaaaaaaaaa', ''),
(34, '', '', 0, 0, '', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `platform`
--
ALTER TABLE `platform`
  ADD PRIMARY KEY (`plt_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`sl`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `platform`
--
ALTER TABLE `platform`
  MODIFY `plt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
