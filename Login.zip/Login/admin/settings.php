<!-- <?php
// session_start();

// if(isset($_SESSION['id']) && isset($_SESSION['username'])){
?> -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>            
    <script src="jquery.tabledit.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"  >
    <link rel="stylesheet" href="admin/style.css">
    <link rel="icon" type="iamge/x-icon" href="image/logo.png" />
   
</head>
<style>
    body{
        background-color: white;
    }

    .cbtn {

        background-color: #2ab4ec;
        color: white;
        width: 50%;
        padding: 10px;
        position: relative;
        left: 20%;
        cursor: pointer;
    }

    .cdiv {
        border: 1px solid  #2ab4ec;
        height: 250px;
        width: 50%;
        position: relative;
        left: 20%;
        cursor: pointer;
        padding: 5px;
        display: none;
    }

    </style>
<body>

<?php

require_once("./html/header.html");
require_once("./html/sidenavbar.html");

?>

<div class="main">
    <div class="cbtn">Trading Platform</div>
    <div class="cdiv">
        <?php
        $sname="localhost";
        $uname="root";
        $password="";
        $db_name="admin";
        $conn=mysqli_connect($sname,$uname,$password,$db_name);
        if(!$conn){
            echo "Connection failed";
        }
    $sqlQuery = "SELECT * FROM platform ORDER BY plt_id";
$resultSet = mysqli_query($conn, $sqlQuery) or die("database error:". mysqli_error($conn));
?>
<div class="table-responsive">  
    <table id="editableTable" class="table table-bordered table-striped">
	<thead>
		<tr>
			<th>Id</th>
			<th>Name</th>
            <th>Actions</th>
																
		</tr>
	</thead>
	<tbody>
		<?php while( $row = mysqli_fetch_assoc($resultSet) ) { ?>
		   <tr id="<?php echo $row ['plt_id']; ?>">
		   <td><?php echo $row['plt_id']; ?></td>
		   <td><?php echo $row ['plt_name']; ?></td>			   				   				  
		   </tr>
		<?php } ?>
	</tbody>
</table></div></div><br><br>
    <div class="cbtn">Test1</div>
    <div class="cdiv"></div><br><br>
    <div class="cbtn">Test2</div>
    <div class="cdiv"></div><br><br>
    <div class="cbtn">Test3</div>
    <div class="cdiv"></div><br><br>
    <div class="cbtn">Test4</div>
    <div class="cdiv"></div>

</div>

<script>
    $(".settings").addClass("active");

    $(".cbtn").click(function(){
        $(this).closest('div').next('.cdiv').slideToggle();
     });


   
     
$(document).ready(function(){  
     $('#editable_table').Tabledit({
      url:'action.php',
      columns:{
       identifier:[0, "plt_id"],
       editable:[[1, 'plt_name']]
      },
      restoreButton:false,
      onSuccess:function(data, textStatus, jqXHR)
      {
       if(data.action == 'delete')
       {
        $('#'+data.id).remove();
       }
      }
     });
 
});  
 

</script>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" ></script>
</html>
<!-- <?php
// }
//  else{
//     header("Location: ../login.php");
//  }
?> -->