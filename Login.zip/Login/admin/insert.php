<?php
	
 date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)

require_once('../config/config.php');

  $name = $_POST["name"];
  $platf = $_POST["platf"];
  $category = $_POST["category"];
  $validity = $_POST["validity"];
  $description = $_POST["description"];
  $descriptioninput = $_POST["descriptioninput"];
  $tags = $_POST["tags"];
  $price = $_POST["price"];
  $discount = $_POST["discount"];
  $image = $_POST["image"];
  $userguide = $_POST["userguide"];
  
 

  $sql = "INSERT INTO `product`(`category`, `name`, `cost`, `discount`, `image`, `userguide`, `description`, `input_description`, `validity`, `tags`, `Platform`) VALUES ('".$category."','".$name."','".$price."','".$discount."','".$image."','".$userguide."','".$description."','".$descriptioninput."','".$validity."','".$tags."','".$platf."') ";
  $result=$conn->query($sql);

  echo $sql;
?>