<?php
session_start();

if(isset($_SESSION['id']) && isset($_SESSION['username'])){
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"  >
    <link rel="stylesheet" href="admin/style.css">
    <link rel="icon" type="iamge/x-icon" href="image/logo.png" />
   
</head>
<style>
    body{
        background-color: white;
    }
  
    
.main{
    position: absolute;
    width: 50%;
    font-size:17px;
    text-decoration:none;
    left:190px;
}

.selectt {

    border: 1px solid lightgrey !important;
    width: 100%;
    border-radius: 5px !important;
    padding: 8px !important;
}
   </style>
<body>

<?php

require_once("./html/header.html");
require_once("./html/sidenavbar.html");
?>
<div class ="main">
    
<table id="example" class="table-hover">
      <thead>
        <th><center>Sl. No.</center></th>
        <th>Product Name</th>
        <th>Platform</th>
        <th>Category</th>
        <th>Validity</th>
        <th>Description</th>
        <th>Description of Input</th>
        <th>Tags</th>
        <th>Price</th>
        <th>Discount</th>
        <th>Image</th>
        <th>User Guide</th>
      </thead>
      <tbody>
      
      <?php
            require_once('../config/config.php');

            $result = $conn->query("SELECT * FROM `product`");
            if($result == false)
            {
              echo "query not running";
              exit;
            }

              $i =0;
                while($rowval = mysqli_fetch_array($result))
                {
                  $i++;

                  echo '<tr>';

                   echo '<td><center>'.$i.'</center></td>';
                   echo '<td contenteditable>'.$rowval['name'].'</td>';
                   echo '<td contenteditable>'.$rowval['Platform'].'</td>';
                   echo '<td contenteditable>    <select class="btn selectt" id="category" required>
                   <option selected>'.$rowval['category'].'</option>
                   <option value="Expert Advisor">Expert Advisor</option>
                   <option value="Indicator">Indicator</option>
                   <option value="Script">Script</option>
              </select></td>';
                   echo '<td contenteditable> <select class="btn selectt" id="validity" required>
                   <option selected>'.$rowval['validity'].'</option>
                   <option value="One month">One month</option>
                   <option value="One year">One year</option>
                   <option value="Lifetime">Lifetime</option>
              </select></td>';
                   echo '<td contenteditable>'.$rowval['description'].'</td>';
                   echo '<td contenteditable>'.$rowval['input_description'].'</td>';
                   echo '<td contenteditable>'.$rowval['tags'].'</td>';
                   echo '<td contenteditable>'.$rowval['cost'].'</td>';
                   echo '<td contenteditable>'.$rowval['discount'].'</td>';
                   echo '<td contenteditable> <input type="file" style="display:block" class="form-control-file btn selectt" id="image">'.$rowval['image'].'</td>';
                   echo '<td contenteditable >'.$rowval['userguide'].'</td>';
                //    echo "<td><a href='javascript:void(0)' onclick='editData(".$rowval['sl'].")'>Edit</a></td>";

                   echo '</tr>';

                }

        ?>

     </tbody>
 </table>

</div>




<script>
    $(".pro").addClass("active");
    
 var image = "";
  
    $("#image").change(function(){

var file_data = $(this).prop("files")[0];   
var form_data = new FormData();
form_data.append("file", file_data);
image = file_data.name;


$.ajax({
        url: "upload.php",
        dataType: 'script',
        cache: false,
        contentType: false,
        processData: false,
        data: form_data,                         
        type: 'post',
        success: function(path){

      }, error: function(path){

      }

  });

});
  


$(document).ready( function () {
    $('#example').DataTable();
  } );
</script>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" ></script>
</html>
<?php
}
 else{
    header("Location: ../login.php");
 }
?>