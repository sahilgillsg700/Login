<!-- <?php
// session_start();

// if(isset($_SESSION['id']) && isset($_SESSION['username'])){
?> -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"  >
    <link rel="stylesheet" href="admin/style.css">
    <link rel="icon" type="iamge/x-icon" href="image/logo.png" />
   
</head>
<style>
    body{
        background-color: white;
    }
  
   .space{
     position:absolute;
     top:40px;
   } 
   .space1{
     position:absolute;
     top:60px;
   } 
.main{
    position: absolute;
    width: 50%;
    font-size:17px;
    text-decoration:none;
    left:190px;
}

.selectt {

    border: 1px solid lightgrey !important;
    width: 100%;
    border-radius: 5px !important;
    padding: 8px !important;
}
.selectt1{
border: 1px solid lightgrey !important;
height:100px;
width: 100%;
border-radius: 5px !important;
padding: -3px !important;
}
img{
  width: 10%;
    /* position: absolute; */
    /* top: 38px;
    left: 31px; */
    margin: 10px;
}
   </style>
<body>

<?php

require_once("./html/header.html");
require_once("./html/sidenavbar.html");
?>
<div class ="main">
    <form action="" method="post">
   <div class="form-group row">
<label for="inputPassword3" class="col-sm-3 col-form-label">Product Name </label>
    <div class="col-sm-9">
    <input type="name" class="form-control" id="name" placeholder="Enter product name"  required>
  </div>
</div> 


   <div class="form-group row">
<label for="inputPassword3" class="col-sm-3 col-form-label">Trading platform</label>
    <div class="col-sm-9">
    <?php

$sname="localhost";
$uname="root";
$password="";
$db_name="admin";
$conn=mysqli_connect($sname,$uname,$password,$db_name);
if(!$conn){
    echo "Connection failed";
}
?>
    <select class="btn selectt" id="category" required>
      <?php
      $a=mysqli_query($conn,"SELECT * FROM platform");
      while($row=mysqli_fetch_array($a))     {
        ?>
          <option ><?php echo $row["plt_name"];?></option>
        <?php
      }
       ?>
             </select>
  </div>
</div>



   <div class="form-group row">
<label for="inputPassword3" class="col-sm-3 col-form-label">Category</label>
    <div class="col-sm-9">
    <select class="btn selectt" id="category" required>
                  <!-- <option selected>Choose...</option> -->
                  <option value="Expert Advisor">Expert Advisor</option>
                  <option value="Indicator">Indicator</option>
                  <option value="Script">Script</option>
             </select>
  </div>
</div>

<div class="form-group row">
<label for="inputPassword3" class="col-sm-3 col-form-label">Validity</label>
    <div class="col-sm-9">
    <select class="btn selectt" id="validity" required>
                  <!-- <option selected>Choose...</option> -->
                  <option value="One month">One month</option>
                  <option value="One year">One year</option>
                  <option value="Lifetime">Lifetime</option>
             </select>
  </div>
</div>
   <div class="form-group row">
<label for="inputPassword3" class="col-sm-3 col-form-label">Description </label>
    <div class="col-sm-9">
    <textarea class="form-control" id="description" rows="3"></textarea>
  </div>
</div>

  <div class="form-group row">
<label for="inputPassword3" class="col-sm-3 col-form-label">Description of Input</label>
    <div class="col-sm-9">
    <textarea class="form-control" id="descriptioninput" rows="3"></textarea>
  </div>
</div>

<div class="form-group row">
<label for="inputPassword3" class="col-sm-3 col-form-label">Tags</label>
    <div class="col-sm-9">
    <textarea class="form-control" id="tags" rows="2"></textarea>
  </div>
</div>

  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-3 col-form-label">Price</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="price" placeholder="Enter the price" required>
    </div>
</div>
    <div class="form-group row">
    <label for="inputPassword3" class="col-sm-3 col-form-label">Discount</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="discount" placeholder="Enter the discount" required>
    </div>
</div>


<div class="form-group row">
<label for="inputPassword3" class="col-sm-3 col-form-label">Image</label>
    <div class="col-sm-9">
    <!-- <input type="file" class="form-control-file btn selectt" id="image"  onchange="preview()"required>
    <img id="frame" src="" width="100px" height="100px"/> -->
    <div class="selectt1">
    <input type="file" class="form-control-file btn " multiple id="gallery-photo-add">
       <div class="gallery"></div>
       </div>
    </div>
</div>

<div class="form-group row ">
<label for="inputPassword3" class="col-sm-3 col-form-label ">User Guide</label>
    <div class="col-sm-9">
    <input type="file" class="form-control-file selectt " id="userguide" required>
  </div>
</div>


    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <center><button type="submit" class="btn btn-success" id="submit"><i class="fa fa-check"></i>&nbsp;Submit</button></center>
      </div>
    </div>
 
</form>
</div>




<script>

$(function() {

    var imagesPreview = function(input, placeToInsertImagePreview) {

        if (input.files) {
            var filesAmount = input.files.length;

            for (i = 0; i < 5; i++) {
                var reader = new FileReader();

                reader.onload = function(event) {
                  var div = document.createElement("div");
                   div.innerhtml= $($.parseHTML('<img>')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
                }
                reader.readAsDataURL(input.files[i]);
               
            }
        }

    };
  
    $('#gallery-photo-add').on('change', function() {
        imagesPreview(this, 'div.gallery');
    });
      
});
    var platf = "";
    var image = "";
    var userguide = "";

    $(".mt").click(function(){
        if($(this).prop("checked")==true){
            platf = $(this).val();
           
        }

    });

    $("#image").change(function(){

      var file_data = $(this).prop("files")[0];   
      var form_data = new FormData();
      form_data.append("file", file_data);
      image = file_data.name;


      $.ajax({
              url: "upload.php",
              dataType: 'script',
              cache: false,
              contentType: false,
              processData: false,
              data: form_data,                         
              type: 'post',
              success: function(path){

            }, error: function(path){

            }

        });

    });
   
    $("#userguide").change(function(){

        var file_data = $(this).prop("files")[0];   
        var form_data = new FormData();
        form_data.append("file", file_data);
        userguide = file_data.name;


        $.ajax({
                url: "upload.php",
                dataType: 'script',
                cache: false,
                contentType: false,
                processData: false,
                data: form_data,                         
                type: 'post',
                success: function(path){

            }, error: function(path){

            }

        });

    });

    $("form").submit(function(e){
      e.preventDefault();
      var name = $("#name").val();
      var category = $("#category").val();
      var validity = $("#validity").val();
      var description = $("#description").val();
      var descriptioninput = $("#descriptioninput").val();
      var tags = $("#tags").val();
      var price = $("#price").val();
      var discount = $("#discount").val();
         

      $.post('insert.php',{
        name,
        platf,
        category,
        validity,
        description,
        descriptioninput,
        tags,
        price,
        discount,
        image,
        userguide

      },function(data){

      });

    });

</script>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" ></script>
</html>
<!-- <?php
// }
//  else{
//     header("Location: ../login.php");
//  }
?> -->