<header class="head" style="border-bottom: 2px solid lightgrey ;box-shadow: 4px 6px 8px 1px rgb(204,228,249,1);
      color: rgb(29, 94, 235);
      padding: 10px 0 10px 0 ;"> 
    <center><h2>Swedish Personal Identity Number (Bank ID) Validation</h2></center>
</header><br><br>