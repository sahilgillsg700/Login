-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 11, 2022 at 12:18 PM
-- Server version: 5.7.32-35-log
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dblhpgv19bg88d`
--

-- --------------------------------------------------------

--
-- Table structure for table `partrex_api_response`
--

CREATE TABLE `partrex_api_response` (
  `sn` int(11) NOT NULL,
  `result` varchar(50) NOT NULL,
  `orderRef` varchar(200) NOT NULL,
  `pno` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `checksum` varchar(500) NOT NULL,
  `certStartDate` date NOT NULL,
  `refID` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `partrex_api_response`
--

INSERT INTO `partrex_api_response` (`sn`, `result`, `orderRef`, `pno`, `name`, `checksum`, `certStartDate`, `refID`) VALUES
(5, 'completed', '92d9c3a5-d813-4457-a50d-e4538ebf2112', '198610219126', 'Vibhuti Singh', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(6, 'completed', 'd6362767-3698-404a-abaf-ed7eb724b447', '198610219126', 'Vibhuti Singh', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(7, 'completed', '8ec43fc2-1b0d-41eb-99cb-f1832e690134', '198610219126', 'Vibhuti Singh', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(8, 'completed', '2a2c2d80-ab47-4365-8a34-cc664eeb7a29', '198610219126', 'Vibhuti Singh', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(9, 'completed', '0b413e5c-a3e3-4dd3-a15b-e792e03f1188', '198610219126', 'Vibhuti Singh', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(10, 'completed', '4266e0bd-e2d3-4505-9f48-47f884739170', '198610219126', 'Vibhuti Singh', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(11, 'completed', '7555a737-f9ed-4bb8-901e-45a9b5f88444', '198610219126', 'Vibhuti Singh', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(12, 'completed', '683fed45-ddf3-41c6-8afb-707956ecdac6', '198610219126', 'Vibhuti Singh', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(13, 'completed', '902da331-1668-452c-86b9-e7496f52e77e', '198610219126', 'Vibhuti Singh', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(14, 'completed', '24a11eea-7766-48bc-a145-0c76a22216ce', '198610219126', 'Vibhuti Singh', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(15, 'userCancel', 'e4442319-1b83-4152-ab5e-342330f26141', '198610219126', '', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(16, 'userCancel', 'ef79e53a-b559-4f11-949b-59f525d5ea79', '198610219126', '', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(17, 'userCancel', '04e6280d-c87d-43dd-b2e0-6a1cd101518d', '198610219126', '', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(18, 'startFailed', '48724e32-4bed-49b4-bdc8-9b9b2f63ac66', '', '', '8450ee2a71798d4261008662998c2716', '0000-00-00', 12398698),
(19, 'completed', '3b2fb992-cde5-448b-9d22-f4486c5cde3c', '198610219126', 'Vibhuti Singh', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(20, 'cancelled', '0d042fb3-7434-4acd-a64d-6a14e1751dff', '198610219126', '', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(21, 'expiredTransaction', 'b5fbe4de-79d4-45f0-a11c-50b970c2f180', '198303022753', '', 'bea652123070db2e91279e430e66af36', '0000-00-00', 12398698),
(22, 'expiredTransaction', '09009870-eb73-4130-a666-41921203a75e', '198303022753', '', 'bea652123070db2e91279e430e66af36', '0000-00-00', 12398698),
(23, 'expiredTransaction', '02f3974c-b954-4f65-8be3-603af5e6a515', '198303022753', '', 'bea652123070db2e91279e430e66af36', '0000-00-00', 12398698),
(24, 'expiredTransaction', '4f216470-21c1-4ee6-b040-d52e553cf974', '198610219126', '', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(25, 'completed', '2e186b7b-c1d9-4ae2-9320-ab43468554a5', '198610219126', 'Vibhuti Singh', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(26, 'userCancel', 'd15e8f25-f2fa-49c2-ab61-d6a65aef7211', '198610219126', '', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(27, 'expiredTransaction', 'c3ac8786-c2d5-4a4c-8161-ea5b57309d64', '198610219126', '', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(28, 'cancelled', '9d9284dc-6a9a-4e2c-b59b-0e652cb3ea1e', '198610219126', '', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(29, 'expiredTransaction', '773cae9b-de83-449c-9ae3-81b6c968cec8', '198610219126', '', '92b775563661344e1af576928879f515', '0000-00-00', 12398698),
(30, 'expiredTransaction', '5b815362-932b-4c69-b756-220923f824b8', '1111111111', '', '083a9185bb0665b6628365844ec20f4d', '0000-00-00', 12398698),
(31, 'expiredTransaction', '0d00ac22-b23a-4e70-8d7c-555c4acb0aa5', '1111111111', '', '083a9185bb0665b6628365844ec20f4d', '0000-00-00', 12398698),
(32, 'completed', '4ed31a94-6a3e-44d4-8305-6254e5c064e4', '199010031327', 'Debashree Waddadar', '9ba8a69b9af7640e8335b4a805381109', '0000-00-00', 12398698),
(33, 'completed', 'd6484953-7bee-4455-bcd8-55409aae268a', '199010031327', 'Debashree Waddadar', '9ba8a69b9af7640e8335b4a805381109', '0000-00-00', 12398698),
(34, 'completed', '4e54f21a-a3c1-4661-9d71-88d0e85b83d8', '199010031327', 'Debashree Waddadar', '9ba8a69b9af7640e8335b4a805381109', '0000-00-00', 12398698),
(35, 'userCancel', 'a84e79f9-a7c6-4b2c-81e4-06e31b218db1', '199010031327', '', '9ba8a69b9af7640e8335b4a805381109', '0000-00-00', 12398698),
(36, 'completed', '392cf88a-c7fb-4c0a-ac53-8f511704fab2', '199010031327', 'Debashree Waddadar', '9ba8a69b9af7640e8335b4a805381109', '0000-00-00', 12398698),
(37, 'completed', 'da698ddf-e10a-4048-bf6d-7c677ef1f52c', '199010031327', 'Debashree Waddadar', '9ba8a69b9af7640e8335b4a805381109', '0000-00-00', 12398698),
(38, 'completed', 'aea863da-e46b-44f0-82aa-3580ca13fd86', '199010031327', 'Debashree Waddadar', '9ba8a69b9af7640e8335b4a805381109', '0000-00-00', 12398698),
(39, 'cancelled', '9ecbe331-94a1-4934-8999-33c43b7613fa', '199010031327', '', '9ba8a69b9af7640e8335b4a805381109', '0000-00-00', 12398698),
(40, 'completed', 'd2207d64-5d9b-4057-8391-7eaaeb04fcc4', '199010031327', 'Debashree Waddadar', '9ba8a69b9af7640e8335b4a805381109', '0000-00-00', 12398698),
(41, 'completed', '65364642-a543-4688-b141-ba705583abb9', '199010031327', 'Debashree Waddadar', '9ba8a69b9af7640e8335b4a805381109', '0000-00-00', 12398698),
(42, 'completed', '55e04757-d727-4c8d-ac04-5e7e7c00a134', '199010031327', 'Debashree Waddadar', '9ba8a69b9af7640e8335b4a805381109', '0000-00-00', 12398698),
(43, 'cancelled', 'ea0eb9b8-8da5-4893-853a-b8e22d021204', '1212121212', '', '37f7a881475777ebbbb3617ea3ce9bfe', '0000-00-00', 12398698),
(44, 'cancelled', '0c4cf17f-040d-4cec-9384-1ac734fca67e', '1212121212', '', '37f7a881475777ebbbb3617ea3ce9bfe', '0000-00-00', 12398698),
(45, 'cancelled', 'b9eb9bbd-91c8-4068-98a1-3b5e40a4dfc7', '1212121212', '', '37f7a881475777ebbbb3617ea3ce9bfe', '0000-00-00', 12398698),
(46, 'expiredTransaction', '196c8d38-c575-4d2e-9c90-a80925975056', '7545053841', '', '61dd15b6267f692036f6ffcf912f75a1', '0000-00-00', 12398698),
(47, 'expiredTransaction', 'c2b171a2-400a-479c-8c00-11951763e91b', '9664780125', '', '7bdf976af429a4673c5fb3774f1ada0b', '0000-00-00', 12398698),
(48, 'expiredTransaction', 'c194040e-1fde-4555-86ea-a84f2ba83006', '1212121212', '', '37f7a881475777ebbbb3617ea3ce9bfe', '0000-00-00', 12398698),
(49, 'cancelled', '696a14e4-9bfe-478f-acc4-a49c93937a88', '1212121212', '', '37f7a881475777ebbbb3617ea3ce9bfe', '0000-00-00', 12398698),
(50, 'cancelled', 'e1de25da-60a2-402a-8da3-89aeab453b99', '201105019093', '', '60bc261f16daa72d71444c347424b181', '0000-00-00', 12398698),
(51, 'cancelled', '0635b44c-62bb-418e-91fc-f8bb36076673', '2342423445', '', '3ea5e2fbb690e199c67b92713d85ecf0', '0000-00-00', 12398698),
(52, 'cancelled', 'c11bfd6b-316b-4346-8784-0104b746a128', '2342423445', '', '3ea5e2fbb690e199c67b92713d85ecf0', '0000-00-00', 12398698),
(53, 'expiredTransaction', '39db6202-380b-4a0e-a325-9b789f8c08af', '2342423445', '', '3ea5e2fbb690e199c67b92713d85ecf0', '0000-00-00', 12398698),
(54, 'cancelled', '5b20e73b-9de1-4763-a469-5ec2875fd626', '1212121212', '', '37f7a881475777ebbbb3617ea3ce9bfe', '0000-00-00', 12398698),
(55, 'expiredTransaction', '70fab477-7991-47ee-adb7-66a81ffbfa78', '1111111111', '', '083a9185bb0665b6628365844ec20f4d', '0000-00-00', 12398698);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `partrex_api_response`
--
ALTER TABLE `partrex_api_response`
  ADD PRIMARY KEY (`sn`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `partrex_api_response`
--
ALTER TABLE `partrex_api_response`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
